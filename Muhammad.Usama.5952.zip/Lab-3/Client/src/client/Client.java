/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import javax.swing.JOptionPane;
import java.util.Scanner;
import jdk.internal.util.xml.impl.Input;

/**
 *
 *
 */
public class Client {

    /**
     * @param args the command line arguments
     */
    
    public static Record Input()
    {
        Scanner s = new Scanner(System.in);
            
            System.out.println("Please Select the Operation:\n 1: for New Record \n 2: For Search");
            
            int operation = Integer.parseInt(s.nextLine());
            String username = s.nextLine();
            Record newRec;
            if(operation == 1)
            {
               String notes = s.nextLine();
               newRec = new Record(username,notes,1);
               
            }
            else
            {
                 newRec = new Record(username,"",2);
            }
            return newRec;
    }
    
    
    
    public static void main(String[] args) 
    {
        try
        {
            Socket sender = new Socket("localhost",9001);
            Record newRec = Input();
            ObjectOutputStream outToServer = new ObjectOutputStream(sender.getOutputStream());
            ObjectInputStream inFromServer = new ObjectInputStream(sender.getInputStream());
            outToServer.writeObject(newRec);
           
            if(newRec.operation == 2)
            {
                while(true)
                {
                    Record newRec1 = (Record)inFromServer.readObject();
                    if(newRec1.Username.equals(""))
                        break;
                    System.out.println("User Name: "+newRec1.Username);
                    System.out.println("Notes : "+newRec1.Note);
                }
            }
            
            sender.close();   
        }
        catch(Exception e)
        {
            System.out.println("Exception");
            System.out.println(e.getMessage());
        }
    }
    
}
