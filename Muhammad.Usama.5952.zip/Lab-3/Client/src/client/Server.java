/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

/**
 *
 * 
 */
public class Server {

  
    public static void main(String[] args)
    {
        try{
            ArrayList<Record> list = new ArrayList<Record>();
            ServerSocket listener = new ServerSocket(9001);
            while(true)
            {
                Socket socket = listener.accept();    
                ObjectOutputStream  OuttoCLient = new ObjectOutputStream (socket.getOutputStream ());
                ObjectInputStream inFromClient = new ObjectInputStream(socket.getInputStream());
                Record newRec ;
                newRec = (Record)inFromClient.readObject();
                if(newRec.operation == 1)
                    list.add(newRec);
                else
                {
                    for(int i = 0; i < list.size();++i)
                    {
                        if(list.get(i).Username.equals(newRec.Username))
                        {
                            OuttoCLient.writeObject(list.get(i));
                        }
                    }
                    Record newr = new Record("", "", 0);
                    OuttoCLient.writeObject(newr);
                }
                System.out.println(newRec.Username);
                       
            }
            
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        
        
    }
    
}
