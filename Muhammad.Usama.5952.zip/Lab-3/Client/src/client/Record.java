/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;


public class Record implements java.io.Serializable
{
    public String Username;
    public String Note;
    public int operation;
    public Record(String A,String B, int Op)
    {
        Username = A ;
        Note = B;
        operation = Op;
    }
    
    
    public String getName()
    {
        return Username;
    }
    
    public String getNotes()
    {
        return Note;
    }
    
}
