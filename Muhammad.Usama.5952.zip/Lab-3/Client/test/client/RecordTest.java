/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author KuldeepKumar
 */
public class RecordTest {
    
    public RecordTest() {
    }

    /**
     * Test of getName method, of class Record.
     */
    @Test
    public void testGetName() {
        System.out.println("getName");
        Record instance = new Record("Kuldeep", "asdasd", 1);
        String expResult = "Kuldeep";
        String result = instance.getName();
        assertEquals(expResult, result);
       
    }

    /**
     * Test of getNotes method, of class Record.
     */
    @Test
    public void testGetNotes() {
        System.out.println("getNotes");
        Record instance = new Record("Kuldeep", "asdasd", 1);
        String expResult = "asdasd";
        String result = instance.getNotes();
        assertEquals(expResult, result);
    }
    
}
